// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");

// const app = express();

// var corsOptions = {
//   origin: "http://localhost:8081"
// };

// app.use(cors(corsOptions));

// // parse requests of content-type - application/json
// app.use(bodyParser.json());

// // parse requests of content-type - application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: true }));

// // simple route
// app.get("/", (req, res) => {
//   res.json({ message: "Welcome to Sara's application." });
// });

// const db = require("./app/models");
// db.mongoose
//   .connect(db.url, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true
//   })
//   .then(() => {
//     console.log("Connected to the database!");
//   })
//   .catch(err => {
//     console.log("Cannot connect to the database!", err);
//     process.exit();
//   });

// // set port, listen for requests
// const PORT = process.env.PORT || 8080;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}.`);
// });


//2
// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");

// const app = express();

// var corsOptions = {
//   origin: ["http://localhost:8081", "http://localhost:8082"]
// };

// app.use(cors(corsOptions));

// // parse requests of content-type - application/json
// app.use(bodyParser.json());

// // parse requests of content-type - application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: true }));

// // simple route
// app.get("/", (req, res) => {
//   res.json({ message: "Welcome to Sara's application." });
// });

// const db = require("./app/models");
// db.mongoose
//   .connect(db.url, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true
//   })
//   .then(() => {
//     console.log("Connected to the database!");
//   })
//   .catch(err => {
//     console.log("Cannot connect to the database!", err);
//     process.exit();
//   });

// // set port, listen for requests
// const PORT =  8080;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}.`);
// });


//3
// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");

// const app = express();

// var corsOptions = {
//   origin: ["http://localhost:8081", "http://localhost:8082"]
// };

// app.use(cors(corsOptions));
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));

// app.get("/", (req, res) => {
//   res.json({ message: "Welcome to Sara's application." });
// });

// // Define a route for handling GET requests to /api/tutorials
// app.get("/api/tutorials", (req, res) => {
//   // Logic to retrieve tutorials from the database or mock data
//   res.json({ message: "List of tutorials" });
// });

// const db = require("./app/models");
// db.mongoose
//   .connect(db.url, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true
//   })
//   .then(() => {
//     console.log("Connected to the database!");
//   })
//   .catch(err => {
//     console.log("Cannot connect to the database!", err);
//     process.exit();
//   });

// const PORT = 8080;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}.`);
// });


//4
// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");

// const app = express();

// var corsOptions = {
//   origin: ["http://localhost:8081", "http://localhost:8082"]
// };

// app.use(cors(corsOptions));
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));

// app.get("/", (req, res) => {
//   res.json({ message: "Welcome to Sara's application." });
// });

// // Define a route for handling GET requests to /api/tutorials
// app.get("/api/tutorials", (req, res) => {
//   // Logic to retrieve tutorials from the database or mock data
//   res.json({ message: "List of tutorials" });
// });

// // Define a route for handling POST requests to /api/tutorials
// app.post("/api/tutorials", (req, res) => {
//   // Logic to handle the POST request and save the tutorial to the database
//   // You can access the request body using req.body
//   const tutorialData = req.body;

//   // Example: Save the tutorial data to the database
//   // Replace this with your actual database logic
//   // For simplicity, this example responds with the saved data
//   res.json({ message: "Tutorial saved successfully", data: tutorialData });
// });

// const db = require("./app/models");
// db.mongoose
//   .connect(db.url, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true
//   })
//   .then(() => {
//     console.log("Connected to the database!");
//   })
//   .catch(err => {
//     console.log("Cannot connect to the database!", err);
//     process.exit();
//   });

// const PORT = 8080;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}.`);
// });

//5
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

var corsOptions = {
  origin: ["http://localhost:8081", "http://localhost:8082", "*"],
  credentials: true,
};

app.use(cors(corsOptions));

app.use(function(req, res, next) {
  res.header(
    "Access-Control-Allow-Headers",
    'Origin, X-Requested-With, Content-Type, Accept',
  );
  res.header("Access-Control-Allow-Credentials", "true");
  next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get("/", (req, res) => {
  res.json({ message: "Welcome to Sara's application." });
});

// // Define a route for handling GET requests to /api/tutorials
// app.get("/api/tutorials", (req, res) => {
//   // Logic to retrieve tutorials from the database or mock data
//   res.json({ message: "List of tutorials" });
// });

// // Define a route for handling POST requests to /api/tutorials
// app.post("/api/tutorials", (req, res) => {
//   // Logic to handle the POST request and save the tutorial to the database
//   // You can access the request body using req.body
//   const tutorialData = req.body;

//   // Example: Save the tutorial data to the database
//   // Replace this with your actual database logic
//   // For simplicity, this example responds with the saved data
//   res.json({ message: "Tutorial saved successfully", data: tutorialData });
// });

// // Define a route for handling DELETE requests to /api/tutorials
// app.delete("/api/tutorials", (req, res) => {
//   // Logic to handle the DELETE request (e.g., delete all tutorials from the database)
//   // Replace this with your actual database logic
//   // For simplicity, this example responds with a success message
//   res.json({ message: "All tutorials deleted successfully" });
// });

const db = require("./app/models");
db.mongoose
  .connect(db.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    console.log("Connected to the database!");
  })
  .catch(err => {
    console.log("Cannot connect to the database!", err);
    process.exit();
  });


require("./app/routes/tutorial.routes")(app);

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});






