import axios from "axios";
export default axios.create({
 baseURL: "http://localhost:8080/api",
 headers: {
   "Content-type": "application/json"
 }
 
},
// await axios.post('http://localhost:8080/send_mail','')
);



// import axios from "axios";

// const API_URL = "http://localhost:8080/api";

// export default axios.create({
//   baseURL: API_URL,
//   headers: {
//     "Content-type": "application/json"
//   }
// });
